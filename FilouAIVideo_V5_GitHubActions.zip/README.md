# Filou AI Video V4

Application Android prototype avec architecture :
- Photo → Vidéo (interface prête pour un backend)
- orchestrateur multi-agents
- agent R&D (recherche/propositions, avec validation humaine)
- configuration distante
- versioning
- vérification de mises à jour
- GitHub Actions
- séparation client / serveur pour les secrets

## Démarrage
Ouvre le dossier dans Android Studio et synchronise Gradle.

## Backend
Le client appelle un backend Filou via `FILOU_API_BASE_URL`. Le backend doit stocker les clés des fournisseurs vidéo.

## V4 — Amélioration par idées
Un bouton ✨ permet d'envoyer une nouvelle idée à l'agent Auto-R&D. L'idée est enregistrée comme proposition et doit être validée avant modification ou déploiement.

## V5 — Auto-R&D
- Bouton d'amélioration relié à un contrat `/v1/rd/ideas`.
- Modèles d'idées/propositions et états du pipeline.
- Pipeline documenté et sécurisé : recherche → proposition → tests → validation → déploiement.
- Les clés API restent côté serveur.
