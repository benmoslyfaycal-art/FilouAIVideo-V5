# Filou AI Video V5 — GitHub Actions

Cette version est préparée pour compiler l'APK dans GitHub Actions, sans Google Colab et sans PC.

## Compilation

1. Créer un dépôt GitHub.
2. Importer tout le contenu de ce dossier dans le dépôt.
3. Ouvrir **Actions**.
4. Sélectionner **Filou AI Video V5 - Build APK**.
5. Appuyer sur **Run workflow**.
6. Attendre la fin du job.
7. Dans le workflow terminé, ouvrir **Artifacts** puis télécharger **FilouAIVideo-V5-APK**.
8. Décompresser l'archive téléchargée et installer `FilouAIVideo-V5-debug.apk` sur Android.

## Important

- La compilation est faite sur les serveurs GitHub Actions.
- Aucun secret/API key ne doit être placé dans le code source ou l'APK.
- Les URL `example.com` du projet sont des placeholders : elles devront être remplacées par ton backend lorsque celui-ci sera réellement configuré.
- Le système Auto-R&D est prévu pour fonctionner via un backend autorisé et isolé ; il ne doit pas télécharger/exécuter automatiquement du code inconnu.

## Déclenchement par tag

Créer un tag `v5.0.1`, `v5.1.0`, etc. pour lancer automatiquement une compilation et une Release GitHub.
