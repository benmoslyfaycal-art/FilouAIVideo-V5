package com.filou.aivideo

data class RdIdea(
    val id: String,
    val text: String,
    val status: String = "received",
    val createdAt: Long = System.currentTimeMillis()
)

data class RdProposal(
    val id: String,
    val ideaId: String,
    val title: String,
    val summary: String,
    val risk: String,
    val status: String = "awaiting_approval"
)

enum class RdStatus { RECEIVED, RESEARCHING, PROPOSAL_READY, TESTING, AWAITING_APPROVAL, APPROVED, REJECTED, DEPLOYED, FAILED }
