package com.filou.aivideo

class RdAgent {
 fun propose():List<ResearchProposal> = listOf(
  ResearchProposal("Nouveau modèle vidéo","Évaluer qualité, coût et compatibilité","Moyen"),
  ResearchProposal("Optimisation Photo→Vidéo","Réduire le temps et les échecs","Faible"),
  ResearchProposal("Nouveau style","Ajouter un preset après test","Faible")
 )
}
