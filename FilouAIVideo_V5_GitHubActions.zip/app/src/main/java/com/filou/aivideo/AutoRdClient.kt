package com.filou.aivideo

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID

class AutoRdClient(
    private val baseUrl: String = BuildConfig.FILOU_API_BASE_URL
) {
    private val http = OkHttpClient()

    suspend fun submitIdea(text: String): Result<RdIdea> = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject()
                .put("text", text)
                .put("source", "android")
                .put("appVersion", BuildConfig.VERSION_NAME)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/v1/rd/ideas")
                .post(body)
                .build()

            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("Serveur R&D: HTTP ${response.code}")
                val obj = JSONObject(response.body?.string().orEmpty())
                RdIdea(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    text = obj.optString("text", text),
                    status = obj.optString("status", "received")
                )
            }
        }
    }
}
