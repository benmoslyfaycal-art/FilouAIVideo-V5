package com.filou.aivideo

class FilouOrchestrator(private val config:FilouRemoteConfig) {
 fun buildJob(prompt:String,duration:Int,ratio:String,style:String,preserveIdentity:Boolean):VideoJob {
  val safeDuration=duration.coerceIn(1,config.maxDuration)
  return VideoJob("photo_to_video",prompt,safeDuration,ratio,style,preserveIdentity)
 }

 fun agents():List<String> = listOf(
  "Orchestrateur",
  "Prompt",
  "Vidéo",
  "Audio",
  "Montage",
  "Contrôle qualité",
  "R&D"
 )
}
