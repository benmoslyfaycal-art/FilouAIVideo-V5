package com.filou.aivideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{FilouApp()}}
}

@Composable fun FilouApp(){
 val context=androidx.compose.ui.platform.LocalContext.current
 val scope=rememberCoroutineScope()
 val remote=remember{RemoteConfig(context)}
 val rd=remember{RdAgent()}
 var cfg by remember{mutableStateOf(remote.cached())}
 var photo by remember{mutableStateOf<android.net.Uri?>(null)}
 var prompt by remember{mutableStateOf("")}
 var style by remember{mutableStateOf("Réaliste")}
 var duration by remember{mutableStateOf(10)}
 var ratio by remember{mutableStateOf("9:16")}
 var identity by remember{mutableStateOf(true)}
 var status by remember{mutableStateOf("Filou AI V4 • prêt")}
 var showImprove by remember{mutableStateOf(false)}
 var idea by remember{mutableStateOf("")}

 val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){photo=it}

 LaunchedEffect(Unit){
  cfg=remote.refresh()
  duration=cfg.defaultDuration.coerceAtMost(cfg.maxDuration)
  status=if(cfg.latestVersionCode>3)"Version ${cfg.latestVersionName} disponible" else "Filou AI V3 • à jour"
 }

 MaterialTheme{
  Scaffold(topBar={TopAppBar(title={Text("FILOU AI VIDEO V3")})}){pad->
   Column(Modifier.padding(pad).padding(18.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
     Text("🧠 Multi-agents IA",style=MaterialTheme.typography.headlineSmall)
     IconButton(onClick={showImprove=true}){Icon(Icons.Filled.AutoAwesome,"Améliorer Filou")}
    }
    Text(status,style=MaterialTheme.typography.bodySmall)

    Button({picker.launch("image/*")},Modifier.fillMaxWidth()){Text(if(photo==null)"🖼 Ajouter une photo" else "✓ Photo sélectionnée")}
    OutlinedTextField(prompt,{prompt=it},Modifier.fillMaxWidth(),label={Text("Que doit faire la photo ?")},minLines=4)

    Text("Style")
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Réaliste","Cinéma","Action","Humour").forEach{s->FilterChip(style==s,{style=s},label={Text(s)})}}
    Text("Durée : $duration s")
    Slider(value=duration.toFloat(),onValueChange={duration=it.toInt().coerceAtLeast(1)},valueRange=1f..cfg.maxDuration.toFloat(),steps=(cfg.maxDuration-2).coerceAtLeast(0))
    Text("Format")
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("9:16","16:9","1:1").forEach{r->FilterChip(ratio==r,{ratio=r},label={Text(r)})}}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Préserver l'identité");Switch(identity,{identity=it})}

    Button({
      val job=FilouOrchestrator(cfg).buildJob(prompt,duration,ratio,style,identity)
      status=if(photo==null)"Ajoute une photo." else "Job créé • ${job.style} • ${job.duration}s • prêt pour le backend vidéo"
    },Modifier.fillMaxWidth()){Text("🎬 GÉNÉRER LA VIDÉO")}

    if(cfg.autoResearch){
      HorizontalDivider()
      Text("🔎 Auto-R&D",style=MaterialTheme.typography.titleLarge)
      rd.propose().forEach{p->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(p.title);Text(p.reason,style=MaterialTheme.typography.bodySmall);Text("Risque : ${p.risk} • ${p.status}",style=MaterialTheme.typography.bodySmall)}}}
      Text("Les propositions nécessitent une validation avant modification du produit.",style=MaterialTheme.typography.bodySmall)
    }

    HorizontalDivider()
    OutlinedButton({
      scope.launch{
       status="Vérification distante…"
       cfg=remote.refresh()
       status=if(cfg.latestVersionCode>3)"Mise à jour ${cfg.latestVersionName} disponible" else "Application à jour"
      }
    },Modifier.fillMaxWidth()){Text("🔄 Vérifier les mises à jour")}
    if(showImprove){
      AlertDialog(
        onDismissRequest={showImprove=false},
        title={Text("✨ Améliorer Filou AI")},
        text={
          Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("Écris ta nouvelle idée. L’agent R&D pourra la transformer en proposition de développement, puis la soumettre à validation.")
            OutlinedTextField(idea,{idea=it},Modifier.fillMaxWidth(),label={Text("Nouvelle idée d’amélioration")},minLines=4)
          }
        },
        confirmButton={
          Button(onClick={
            status=if(idea.isBlank())"Écris une idée d’abord." else "Idée enregistrée pour l’Auto-R&D."
            showImprove=false
          }){Text("Envoyer à l’Auto-R&D")}
        },
        dismissButton={TextButton(onClick={showImprove=false}){Text("Annuler")}}
      )
    }
   }
  }
 }
}
