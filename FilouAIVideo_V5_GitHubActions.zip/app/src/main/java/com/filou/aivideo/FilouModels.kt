package com.filou.aivideo

data class FilouRemoteConfig(
    val latestVersionCode:Int=3,
    val latestVersionName:String="3.0",
    val minimumVersionCode:Int=1,
    val updateUrl:String="",
    val photoToVideo:Boolean=true,
    val textToVideo:Boolean=false,
    val videoToVideo:Boolean=false,
    val autoResearch:Boolean=true,
    val autoPrompt:Boolean=true,
    val defaultDuration:Int=10,
    val maxDuration:Int=15
)

data class VideoJob(
    val mode:String,
    val prompt:String,
    val duration:Int,
    val ratio:String,
    val style:String,
    val preserveIdentity:Boolean
)

data class ResearchProposal(
    val title:String,
    val reason:String,
    val risk:String,
    val status:String="À valider"
)
