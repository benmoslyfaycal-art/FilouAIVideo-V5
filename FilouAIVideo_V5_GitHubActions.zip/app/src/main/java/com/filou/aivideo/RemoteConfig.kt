package com.filou.aivideo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class RemoteConfig(private val context:Context) {
 private val prefs=context.getSharedPreferences("filou_remote",Context.MODE_PRIVATE)
 private val client=OkHttpClient()

 fun cached():FilouRemoteConfig=parse(prefs.getString("json",null))

 suspend fun refresh():FilouRemoteConfig=withContext(Dispatchers.IO){
  try{
   val req=Request.Builder().url(BuildConfig.FILOU_CONFIG_URL).build()
   client.newCall(req).execute().use{r->
    if(!r.isSuccessful) return@withContext cached()
    val body=r.body?.string() ?: return@withContext cached()
    prefs.edit().putString("json",body).apply()
    parse(body)
   }
  }catch(_:Exception){cached()}
 }

 private fun parse(raw:String?):FilouRemoteConfig{
  if(raw.isNullOrBlank()) return FilouRemoteConfig()
  return try{
   val j=JSONObject(raw)
   val f=j.optJSONObject("features")?:JSONObject()
   val v=j.optJSONObject("video")?:JSONObject()
   FilouRemoteConfig(
    j.optInt("latestVersionCode",3),
    j.optString("latestVersionName","3.0"),
    j.optInt("minimumVersionCode",1),
    j.optString("updateUrl",""),
    f.optBoolean("photoToVideo",true),
    f.optBoolean("textToVideo",false),
    f.optBoolean("videoToVideo",false),
    f.optBoolean("autoResearch",true),
    f.optBoolean("autoPrompt",true),
    v.optInt("defaultDuration",10),
    v.optInt("maxDuration",15)
   )
  }catch(_:Exception){FilouRemoteConfig()}
 }
}
