plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace="com.filou.aivideo"
    compileSdk=35
    defaultConfig {
        applicationId="com.filou.aivideo"
        minSdk=26
        targetSdk=35
        versionCode = 5
        versionName = "5.0"
        buildConfigField("String","FILOU_CONFIG_URL","\"https://example.com/filou/config.json\"")
        buildConfigField("String","FILOU_API_BASE_URL","\"https://example.com/filou/api/\"")
    }
    buildFeatures { buildConfig=true; compose=true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
