# Filou AI Video V5 — Auto-R&D API

## Goal
Receive improvement ideas from the Android app and process them through a guarded R&D pipeline.

## Endpoint
`POST /v1/rd/ideas`

Request:
```json
{
  "text": "Ajouter un mouvement de caméra plus naturel",
  "source": "android",
  "appVersion": "5.0"
}
```

Response:
```json
{
  "id": "rd-123",
  "text": "Ajouter un mouvement de caméra plus naturel",
  "status": "received"
}
```

## Pipeline
received -> researching -> proposal_ready -> testing -> awaiting_approval -> approved -> deployed

Failures go to `failed`. Rejected proposals go to `rejected`.

## Safety
The R&D agent must work in an isolated branch/workspace. Production code and releases are never changed directly from a user idea. Tests and APK builds must pass, and deployment requires explicit approval.

API keys for AI/model providers stay server-side and are never embedded in the APK.
