# Backend Filou

Le backend doit :
1. recevoir un job Photo→Vidéo ;
2. choisir le fournisseur/modèle ;
3. conserver les clés API côté serveur ;
4. retourner un identifiant de job ;
5. permettre à l'application de récupérer le résultat.

L'Auto-R&D peut proposer des changements, mais une validation est requise avant déploiement.
