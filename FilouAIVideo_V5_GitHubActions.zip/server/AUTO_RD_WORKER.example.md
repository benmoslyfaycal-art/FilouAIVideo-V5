# Example Auto-R&D worker architecture

1. Read `POST /v1/rd/ideas`.
2. Research current documentation/model releases/repos.
3. Produce a proposal with files affected, tests, risks and rollback plan.
4. Create an isolated branch.
5. Ask a coding agent to implement the proposal.
6. Run unit tests, lint and Android APK build.
7. Publish a test artifact.
8. Wait for explicit approval.
9. Merge/deploy only after approval.
10. Keep rollback to the previous release.

This file is an architecture guide, not an autonomous production agent. A real worker requires a server/CI environment and an AI coding/research service.
