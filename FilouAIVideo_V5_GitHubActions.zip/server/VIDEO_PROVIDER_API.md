# Connexion du moteur vidéo

Le client V4 est prévu pour appeler `FILOU_API_BASE_URL`.

## Endpoint
`POST /v1/video/jobs`

Multipart:
- `image`: photo utilisateur
- `prompt`: mouvement demandé
- `duration`: 5/10/15
- `ratio`: 9:16, 16:9, 1:1
- `style`: style choisi
- `preserveIdentity`: true/false

Réponse:
```json
{"jobId":"abc123","status":"queued"}
```

Puis:
`GET /v1/video/jobs/{jobId}`

Réponse finale:
```json
{"jobId":"abc123","status":"completed","videoUrl":"https://..."}
```

Le backend choisit le fournisseur vidéo (OpenArt/Runway/fal/autre) selon la configuration distante. Les clés secrètes restent exclusivement sur le backend.

## Sécurité
Ne mets jamais une clé fournisseur dans l'APK.
