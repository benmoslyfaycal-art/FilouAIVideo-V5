# Filou AI Video V5 — Final

Prototype Android prêt à compiler dans Google Colab et à installer sur Android (minSdk 26).

## Inclus
- Interface Studio simple
- Prompt Studio : coller/copier/améliorer/historique
- Identity Lock activé par défaut dans le workflow
- Model Hub
- Auto-R&D / Evolution Mode avec validation humaine
- Security Center
- Architecture client/serveur sans clés API fournisseurs dans l'APK
- Backend API contract docs

## Important
Le moteur vidéo réel et l'Auto-R&D distant nécessitent un backend. Cette version compile et fournit toute l'interface et les contrats d'intégration, mais ne prétend pas embarquer un modèle vidéo propriétaire ni un agent de développement autonome sur le téléphone.

## Compilation Colab
Utilise `FilouAIVideo_V5_Compiler.ipynb`. Il télécharge le SDK/Gradle nécessaires, construit un APK debug et le place dans `/content/FilouAIVideo_V5/app/build/outputs/apk/debug/app-debug.apk`.
