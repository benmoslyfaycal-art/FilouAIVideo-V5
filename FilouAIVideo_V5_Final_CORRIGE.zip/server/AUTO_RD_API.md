# Auto-R&D API V5
POST /v1/rd/ideas
GET /v1/rd/models
POST /v1/rd/models/{id}/test
POST /v1/rd/proposals/{id}/approve

Pipeline: received -> researching -> proposal_ready -> testing -> awaiting_approval -> approved -> deployed.
Les modèles téléchargés sont testés hors production. Aucun code n'est fusionné sans validation explicite. Les clés fournisseurs restent côté serveur.
