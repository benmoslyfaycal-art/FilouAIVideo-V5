# Video API V5
POST /v1/video/jobs (multipart: image, prompt, duration, ratio, style, preserveIdentity=true)
GET /v1/video/jobs/{jobId}

Le serveur choisit le fournisseur vidéo et garde les clés secrètes. L'application Android ne contient aucune clé fournisseur.
