package com.filou.aivideo

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

private val Bg = Color(0xFF0B0B10)
private val Card = Color(0xFF15151D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FilouApp() }
    }
}

@Composable
fun FilouApp(vm: FilouViewModel = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Color(0xFFB9A7FF))) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF111118)) {
                val items = listOf(Icons.Default.Movie to "Studio", Icons.Default.EditNote to "Prompts", Icons.Default.Psychology to "Modèles", Icons.Default.AutoAwesome to "Auto-R&D", Icons.Default.Security to "Sécurité")
                items.forEachIndexed { i, pair ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(pair.first, null) }, label = { Text(pair.second) })
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> StudioScreen(vm)
                    1 -> PromptScreen(vm)
                    2 -> ModelsScreen(vm)
                    3 -> RdScreen(vm)
                    4 -> SecurityScreen()
                }
            }
        }
    }
}

@Composable fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("Filou AI", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
            Spacer(Modifier.weight(1f)); Surface(shape=RoundedCornerShape(50), color=Color(0xFF17351F)) { Text("● Prête", Modifier.padding(horizontal=10.dp, vertical=5.dp), color=Color(0xFF7BE49A), style=MaterialTheme.typography.labelMedium) }
        }
        subtitle?.let { Text(it, color=Color.LightGray, modifier=Modifier.padding(top=4.dp)) }
    }
}

@Composable fun StudioScreen(vm: FilouViewModel) {
    val context=LocalContext.current
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? -> vm.image=uri }
    Column(Modifier.fillMaxSize()) {
        Header("Studio", "Crée une vidéo sans compliquer le travail")
        LazyColumn(contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
            item {
                OutlinedTextField(value=vm.prompt, onValueChange={vm.prompt=it}, modifier=Modifier.fillMaxWidth().height(150.dp), label={Text("Que veux-tu créer ?")}, placeholder={Text("Ex. scène cinématique sous la pluie..." )})
            }
            item {
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    Button(onClick={picker.launch("image/*")}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.Image,null); Spacer(Modifier.width(6.dp)); Text(if(vm.image==null) "Importer" else "Photo OK") }
                    OutlinedButton(onClick={vm::clearPrompt}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.Clear,null); Spacer(Modifier.width(6.dp)); Text("Effacer") }
                }
            }
            item { IdentityCard() }
            item { Card(modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("🎬 Paramètres rapides", fontWeight=FontWeight.Bold); Text("10 s  •  9:16  •  Réalisme", color=Color.LightGray, modifier=Modifier.padding(top=8.dp)); Text("Les réglages avancés restent optionnels.", color=Color.Gray, modifier=Modifier.padding(top=4.dp)) } } }
            item { Button(onClick={vm.queueJob()}, modifier=Modifier.fillMaxWidth().height(58.dp), shape=RoundedCornerShape(18.dp)) { Icon(Icons.Default.AutoAwesome,null); Spacer(Modifier.width(8.dp)); Text(if(vm.jobQueued) "Génération préparée" else "CRÉER LA VIDÉO", fontWeight=FontWeight.Bold) } }
            item { Text("Le moteur vidéo est connecté au backend via une API sécurisée. Les clés fournisseurs ne sont jamais embarquées dans l'APK.", color=Color.Gray, style=MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable fun IdentityCard() { Card(modifier=Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Color(0xFF171D1A))) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.VerifiedUser,null,tint=Color(0xFF7BE49A)); Spacer(Modifier.width(12.dp)); Column { Text("IDENTITY LOCK — ACTIF", fontWeight=FontWeight.Bold); Text("Préservation prioritaire des traits du visage.", color=Color.LightGray) } } } }

@Composable fun PromptScreen(vm: FilouViewModel) {
    val context=LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Header("Prompt Studio", "Colle, améliore et copie tes prompts")
        Column(Modifier.padding(horizontal=20.dp)) {
            OutlinedTextField(value=vm.prompt, onValueChange={vm.prompt=it}, modifier=Modifier.fillMaxWidth().height(220.dp), label={Text("Ton prompt")})
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={copy(context, vm.prompt)}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.ContentCopy,null); Text("Copier") }
                OutlinedButton(onClick={vm.improvePrompt}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.AutoAwesome,null); Text("Améliorer") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick={vm.savePrompt}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.BookmarkAdd,null); Text("Enregistrer") }
                OutlinedButton(onClick={vm.clearPrompt}, modifier=Modifier.weight(1f)) { Icon(Icons.Default.Delete,null); Text("Effacer") }
            }
            Spacer(Modifier.height(18.dp)); Text("Historique", fontWeight=FontWeight.Bold)
            if(vm.history.isEmpty()) Text("Aucun prompt enregistré.", color=Color.Gray, modifier=Modifier.padding(top=8.dp))
            else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.padding(top=8.dp)) { items(vm.history) { p -> Card(onClick={vm.prompt=p}) { Text(p, Modifier.padding(12.dp), maxLines=3) } } }
        }
    }
}

fun copy(context: Context, text: String) { (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Filou prompt", text)) }

@Composable fun ModelsScreen(vm: FilouViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header("Model Hub", "Nouveaux modèles à analyser et tester")
        LazyColumn(contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Text("🆕 Modèles détectés", fontWeight=FontWeight.Bold) }
            items(vm.models) { m -> Card { Column(Modifier.padding(16.dp)) { Text(m.name, fontWeight=FontWeight.Bold); Text(m.type, color=Color.LightGray); Text(m.note, modifier=Modifier.padding(top=5.dp)); Text("Licence : ${m.license}", color=Color.Gray, style=MaterialTheme.typography.bodySmall, modifier=Modifier.padding(top=5.dp)); Row(Modifier.padding(top=10.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={}) { Text("Voir") }; Button(onClick={}) { Text("Tester") }; OutlinedButton(onClick={}) { Text("Proposer") } } } } }
            item { Text("Le Hub sera alimenté par le backend/Auto-R&D. Un modèle inconnu n'est pas téléchargé ni exécuté automatiquement sur le téléphone.", color=Color.Gray, style=MaterialTheme.typography.bodySmall) }
        }
    }
}

data class ModelItem(val name:String,val type:String,val note:String,val license:String)

@Composable fun RdScreen(vm: FilouViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header("Auto-R&D", "Recherche → test → validation → intégration")
        LazyColumn(contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Card { Column(Modifier.padding(16.dp)) { Text("🧠 Evolution Mode", fontWeight=FontWeight.Bold); Text("L'agent recherche des améliorations, prépare des propositions et les teste en environnement isolé.", color=Color.LightGray, modifier=Modifier.padding(top=6.dp)); Text("Aucun déploiement automatique en production.", color=Color(0xFFFFD27D), modifier=Modifier.padding(top=6.dp)) } } }
            item { Text("Pipeline", fontWeight=FontWeight.Bold) }
            items(listOf("🔎 Recherche","💡 Proposition","🧪 Tests sandbox","🧑‍💻 Validation","🚀 Déploiement approuvé","↩️ Rollback")) { Text(it, Modifier.fillMaxWidth().background(Card, RoundedCornerShape(12.dp)).padding(14.dp)) }
            item { Button(onClick={vm.addRdIdea()}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Lightbulb,null); Spacer(Modifier.width(6.dp)); Text("Soumettre une idée") } }
            item { Text(vm.rdStatus, color=Color.Gray) }
        }
    }
}

@Composable fun SecurityScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("Security Center", "Protection de l'application et du téléphone")
        LazyColumn(contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(listOf("🔐 Clés API : côté serveur uniquement","🌐 Réseau : HTTPS/TLS","📦 Modèles : sandbox avant intégration","📁 Permissions : minimales","🧾 Secrets : jamais dans les logs","🔄 Déploiement : validation + rollback","📵 Pas d'accès SMS/contacts/accessibilité requis")) { s -> Card { Text(s, Modifier.padding(15.dp)) } }
        }
    }
}

class FilouViewModel : androidx.lifecycle.ViewModel() {
    var prompt by mutableStateOf("")
    var image by mutableStateOf<Uri?>(null)
    var jobQueued by mutableStateOf(false)
    var rdStatus by mutableStateOf("Aucune proposition envoyée.")
    var history by mutableStateOf(listOf<String>())
    val models = listOf(
        ModelItem("Model Provider A", "Vidéo", "À évaluer par le benchmark V5", "À vérifier"),
        ModelItem("Model Provider B", "Vidéo / image", "Candidat à tester en sandbox", "À vérifier"),
        ModelItem("Nouveau modèle", "Détection backend", "Sera rempli par le Model Hub", "À vérifier")
    )
    fun clearPrompt(){ prompt="" }
    fun queueJob(){ jobQueued=true }
    fun improvePrompt(){ if(prompt.isNotBlank()) prompt = prompt.trim() + "

Qualité cinématique, mouvements naturels, cohérence temporelle, préservation stricte de l'identité du visage, texture naturelle, sans modification des traits." }
    fun savePrompt(){ if(prompt.isNotBlank()) history=(listOf(prompt)+history).distinct().take(30) }
    fun addRdIdea(){ rdStatus="Idée enregistrée localement. Le backend pourra l'envoyer à /v1/rd/ideas après configuration." }
}
